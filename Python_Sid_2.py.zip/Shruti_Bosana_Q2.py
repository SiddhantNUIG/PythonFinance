#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sat Mar 21 19:45:08 2020

@author: shrutismacbook
"""

import numpy as np
import scipy.stats as stats
import sympy as sy
from sympy.stats import Normal, cdf
from sympy import init_printing
init_printing()


def euro_vanilla_call(SO, X, T, r, sigma):
    

    d1 = (np.log(SO / X) + (r + 0.5 * sigma ** 2) * T) / (sigma * np.sqrt(T))
    d2 = (np.log(SO / X) + (r - 0.5 * sigma ** 2) * T) / (sigma * np.sqrt(T))
    
    call = (SO * stats.norm.cdf(d1, 0.0, 1.0) - X * np.exp(-r * T) * stats.norm.cdf(d2, 0.0, 1.0))
    
    #return call
    print("The value of d1 is:", d1)
    print("The value of d2 is:", d2)
    print("The call option price using Black-Scholes is:", call)

euro_vanilla_call(100, 100, 1, 0.04, 0.2)




def euro_vanilla_put(SO, X, T, r, sigma):
    
   
    d1 = (np.log(SO / X) + (r + 0.5 * sigma ** 2) * T) / (sigma * np.sqrt(T))
    d2 = (np.log(SO / X) + (r - 0.5 * sigma ** 2) * T) / (sigma * np.sqrt(T))
    
    put = (X * np.exp(-r * T) * stats.norm.cdf(-d2, 0.0, 1.0) - SO * stats.norm.cdf(-d1, 0.0, 1.0))
    
    #return put
    print("The value of d1 is:", d1)
    print("The value of d2 is:", d2)
    print("The put option price using Black-Scholes is:", put)

euro_vanilla_put(100, 100, 1, 0.04, 0.2)








def euro_vanilla(SO, X, T, r, sigma, option):
    
  
    d1 = (np.log(SO / X) + (r + 0.5 * sigma ** 2) * T) / (sigma * np.sqrt(T))
    d2 = (np.log(SO / X) + (r - 0.5 * sigma ** 2) * T) / (sigma * np.sqrt(T))
    
    if option == 'call':
        result = euro_vanilla_call(SO, X, T, r, sigma)
        #(SO * stats.norm.cdf(d1, 0.0, 1.0) - X * np.exp(-r * T) * stats.norm.cdf(d2, 0.0, 1.0))
    if option == 'put':
        result = euro_vanilla_put(SO, X, T, r, sigma) 
        #(X * np.exp(-r * T) * stats.norm.cdf(-d2, 0.0, 1.0) - SO * stats.norm.cdf(-d1, 0.0, 1.0))
        
    return result


euro_vanilla(100, 100, 1, 0.04, 0.2, "put")














