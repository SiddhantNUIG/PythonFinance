#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Mar 26 14:31:51 2020

@author: shrutismacbook
"""
import numpy as np
import pandas as pd
#import pandas_datareader.data as getData
import matplotlib.pyplot as plt
from math import exp
#pip install yfinance
import scipy.optimize as optimization
import yfinance as yf
import scipy.stats as stats
import os
os.getcwd()

stock = ['KR', 'T', 'F']
start = pd.to_datetime('2015-02-28') 
end = pd.to_datetime('2020-02-29')
data = yf.download(stock, start=start, end=end)['Adj Close']

import matplotlib.pyplot as plt
data.plot()
plt.show()





risk_free_rate = 4.00

def capm(start_date, end_date, ticker1, ticker2):

	#get the data from Yahoo Finance
	stock1 = yf.download(ticker1, start=start, end=end)
	stock2 = yf.download(ticker2, start=start, end=end)
    #stock3 = yf.download(ticker3, start=start, end=end)

	#we prefer monthly returns instead of daily returns
	return_stock1 = stock1.resample('M').last()
	return_stock2 = stock2.resample('M').last()
	#return_stock3 = stock3.resample('M').last()

	#creating a dataFrame from the data - Adjusted Closing Price is used
	data = pd.DataFrame({'s_adjclose' : return_stock1['Adj Close'], 'm_adjclose' : return_stock2['Adj Close']}, index=return_stock1.index)
	#natural logarithm of the returns
	data[['s_returns', 'm_returns']] = np.log(data[['s_adjclose','m_adjclose']]/data[['s_adjclose','m_adjclose']].shift(1))
	#no need for NaN/missing values values so let's get rid of them
	data = data.dropna()

	#covariance matrix: the diagonal items are the vairances - off diagonals are the covariances
	#the matrix is symmetric: cov[0,1] = cov[1,0] 
	covmat = np.cov(data["s_returns"], data["m_returns"])
	print(covmat)
	
	#calculating beta according to the formula
	beta = covmat[0,1]/covmat[1,1]
	print("Beta from formula:", beta)

	#using linear regression to fit a line to the data [stock_returns, market_returns] - slope is the beta
	beta,alpha = np.polyfit(data["m_returns"], data['s_returns'], deg=1)
	print("Beta from regression:", beta)
	print("Alpha from regression:", alpha)
	
	#plot
	fig,axis = plt.subplots(1,figsize=(20,10))
	axis.scatter(data["m_returns"], data['s_returns'], label="Data points")
	axis.plot(data["m_returns"], alpha + beta*data["m_returns"], color='green', label="CAPM Line")
	plt.title('Capital Asset Pricing Model', fontsize=18)
	plt.xlabel('Market return $r_m$', fontsize=18)
	plt.ylabel('Stock return $r_i$', fontsize=18)
	plt.text(0.08, 0.05, r'$r_i = \alpha + \beta r_m$', color='green', fontsize=18)
	plt.legend()
	plt.grid(True, axis='both')
	plt.show()
	
	#calculate the expected return according to the CAPM formula
	expected_return = risk_free_rate + beta*(data["m_returns"].mean()*12-risk_free_rate)#annualised return (times 12)
	print("Expected return:", expected_return)

if __name__ == "__main__":

    capm('2015-02-28', '2020-02-29', 'T', 'F')
    capm('2015-02-28', '2020-02-29','KR', 'F')
    capm('2015-02-28', '2020-02-29','KR', 'T')









stock = ['KR', 'T', 'F']
start = pd.to_datetime('2015-02-28') 
end = pd.to_datetime('2020-02-29')
data = yf.download(stock, start=start, end=end)['Adj Close']


	
def show_data(data):
    data.plot(figsize=(10,5), title='Stock Price Series')
    plt.ylabel("Adjusted Closing Price")
    plt.show()
    
#we usually use natural logarithm for normalization purposes
def calculate_returns(data):
	returns = np.log(data/data.shift(1))
	return returns;
	
def plot_daily_returns(returns):
	returns.plot(figsize=(10,5), title='Stock Log Returns')
	plt.show()

#print out mean and covariance of stocks within [start_date, end_date]. There are 252 trading days within a year
def show_statistics(returns):
	print(returns.mean()*252)
	print(returns.cov()*252)

#weights defines what stocks to include (with what portion) in the portfolio
def initialize_weights():
	weights = np.random.random(len(stock))
	weights /= np.sum(weights)
	return weights
	
#expected portfolio return
def calculate_portfolio_return(returns, weights):
	portfolio_return = np.sum(returns.mean()*weights)*252
	print("Expected portfolio return:", portfolio_return)

#expected portfolio variance
def calculate_portfolio_variance(returns, weights):
	portfolio_variance = np.sqrt(np.dot(weights.T, np.dot(returns.cov()*252,weights)))
	print("Expected variance:", portfolio_variance)

def generate_portfolios(weights, returns):

	preturns = []
	pvariances = []

	#Monte-Carlo simulation: we generate several random weights -> so random portfolios 
	for i in range(10000):
		weights = np.random.random(len(stock))
		weights/=np.sum(weights)# equivalent to weights = weights/sum(weights)
		preturns.append(np.sum(returns.mean()*weights)*252)
		pvariances.append(np.sqrt(np.dot(weights.T,np.dot(returns.cov()*252,weights))))
	
	preturns = np.array(preturns)
	pvariances = np.array(pvariances)
	return preturns,pvariances

def plot_portfolios(preturns, pvariances):
	plt.figure(figsize=(10,6))
	plt.scatter(pvariances,preturns,c=preturns/pvariances,marker='o')
	plt.grid(True)
	plt.xlabel('Expected Volatility')
	plt.ylabel('Expected Return')
	plt.colorbar(label='Sharpe Ratio')
	plt.show()

# OK this is the result of the simulation ... now we have to find the optimal portfolio with 
# some optimization technique - scipy can optimize functions (minimum/maximum finding)
def statistics(weights, returns):
	portfolio_return=np.sum(returns.mean()*weights)*252
	portfolio_volatility=np.sqrt(np.dot(weights.T,np.dot(returns.cov()*252,weights)))
	return np.array([portfolio_return,portfolio_volatility,portfolio_return/portfolio_volatility])

# [1] means that we want to maximize according to the volatility(risk)
# note: **2 squares the standard deviation to get the variance again
def	min_func_variance(weights, returns):
	return	statistics(weights, returns)[1] **2
	
#  constraints remain the same in optimising based on variance
def optimize_portfolio_variance(weights, returns):
	constraints = ({'type':'eq','fun': lambda x: np.sum(x)-1}) #the sum of weights is 1
	bounds = tuple((0,1) for x in range(len(stock))) #the weights can be 1 at most: 1 when 100% of money is invested into a single stock
	optimum=optimization.minimize(fun=min_func_variance,x0=weights,args=returns,method='SLSQP',bounds=bounds,constraints=constraints) 
	return optimum

# optimal portfolio according to weights: 0 means no shares of that given company 
def print_optimal_portfolio(optimum, returns):
	print("Optimal weights:", optimum['x'].round(3))
	print("Expected return, volatility and Sharpe ratio:", statistics(optimum['x'].round(3),returns))

# [2] means that we want to maximize according to the Sharpe-ratio
# note: maximizing f(x) function is the same as minimizing -f(x) 
def	min_func_sharpe(weights,returns):
	return	-statistics(weights,returns)[2]

# what are the constraints? The sum of weights = 1  f(x)=0 this is the function to minimize
def optimize_portfolio(weights,returns):
	constraints = ({'type':'eq','fun': lambda x: np.sum(x)-1}) #the sum of weights is 1
	bounds = tuple((0,1) for x in range(len(stock))) #the weights can be 1 at most: 1 when 100% of money is invested into a single stock
	optimum_sr=optimization.minimize(fun=min_func_sharpe,x0=weights,args=returns,method='SLSQP',bounds=bounds,constraints=constraints) 
	return optimum_sr
    
def show_optimal_portfolio(optimum, returns, preturns, pvariances):
    plt.figure(figsize=(10,6))
    plt.scatter(pvariances,preturns,c=preturns/pvariances,marker='o')
    plt.grid(True)
    plt.xlabel('Expected Volatility')
    plt.ylabel('Expected Return')
    plt.colorbar(label='Sharpe Ratio')
    plt.plot(statistics(optimum['x'],returns)[1],statistics(optimum['x'],returns)[0],
             'bs',markersize=10.0)
    plt.plot(statistics(optimum_sr['x'],returns)[1],statistics(optimum_sr['x'],returns)[0],
             'b*',markersize=20.0)
    plt.show()

if __name__ == "__main__":
   # data = download_data(stocks)
    show_data(data)
    returns = calculate_returns(data)
    plot_daily_returns(returns)
    show_statistics(returns)
    weights=initialize_weights()
    calculate_portfolio_return(returns,weights)
    calculate_portfolio_variance(returns,weights)
    preturns,pvariances=generate_portfolios(weights, returns)
    plot_portfolios(preturns,pvariances)
    optimum=optimize_portfolio_variance(weights, returns)
    print_optimal_portfolio(optimum, returns)
    optimum_sr=optimize_portfolio(weights, returns)
    show_optimal_portfolio(optimum, returns, preturns, pvariances)
    
    
    
    
 
    
    
    
##################################
#VaR for a portfolio
##################################

stock = ['KR', 'T', 'F']
start = pd.to_datetime('2015-02-28') 
end = pd.to_datetime('2020-02-29')
data = yf.download(stock, start=start, end=end)['Adj Close']

#plot data series	
data.plot(figsize=(10,5), title='Stock Price Series')
plt.ylabel("Adjusted Closing Price")
plt.show()
    
#use natural logarithm for normalization purposes
returns = np.log(data/data.shift(1))

#randomly choose weights
weights = np.random.random(len(stock))
weights /= np.sum(weights)

#daily expected portfolio return
portfolio_return = np.sum(returns.mean()*weights)
print("Expected daily portfolio return:", portfolio_return)

#daily expected portfolio volatility
portfolio_volatility = np.sqrt(np.dot(weights.T, np.dot(returns.cov(),weights)))
print("Expected daily volatility:", portfolio_volatility)

#get the 1 day VaR
alpha=stats.norm.ppf(0.05)
VaR=(portfolio_volatility*alpha)
print('1 day Portfolio Value at risk is: %0.2f' % VaR)

#get the 30 day VaR
n=30 #days
VaR30=(portfolio_return*n)+((portfolio_volatility*np.sqrt(n))*alpha)
print('30 day Portfolio Value at risk is: %0.2f' % VaR30)

#get the dollar amount VaR
S = 1000000 #this is the investment (stocks or whatever) or (1e6=1000000)
dollarVaR30=S*VaR30
print('30 day Portfolio Dollar Value at risk is: $%0.2f' % dollarVaR30)

